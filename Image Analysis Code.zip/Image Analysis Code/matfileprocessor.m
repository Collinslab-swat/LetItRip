%% This script reads the .mat files in the folder spit out by the Wormprocessor code.
%%The mat file contains the x,y coordinates of the spline (ordered head to tail)
%%and corresponding distances to the boundary. These are stored in a 3
%%column matrix named 'spline_matrix'
%%The code maps the spline onto [0(head),1(tail)] and plots the edge
%%distance as a function of the normalized spline length.
%%Code can also be used to get neck length, neck area, worm area and such.
%%The edgedistance plots are then put together into a gif.

%%Written: June 11th 2020, Tapan Goel
%%Modified: June 25th 2020, Tapan Goel

clear all; clc; clf; close all;

%% Read all .tif file names

%define where to start looking for files
impath = 'E:\Schmedtia fission\Image analysis';
imdir = uigetdir(impath, 'image folder to read');  %this folder should contain all .mat files you want to analyze
cd(imdir);  %switch to folder containing files.
files = dir('*.mat');

cd('E:\Schmedtia fission\Image analysis'); %go back to folder containing all the scripts
gap = 1;
%wormlength = zeros(length(820:gap:length(files)),1);i=1;
%necklength = zeros(length(820:gap:length(files)),1);
%neckwidth = zeros(length(820:gap:length(files)),1);
%% Process files
for filenumber = 1:gap:length(files)
    % filenumber
   filename = [files(filenumber).folder '\' files(filenumber).name];
   load(filename,'spline_matrix');
   
  
   
    
%    %% Parameterize the spline
%     curve_coord = 0:(1/(length(spline_matrix(:,1))-1)):1; %coordinate along the spline.
%     %%parameterize by arclength
%     local_arc_elements = (spline_matrix(2:end,1)-spline_matrix(1:end-1,1)).^2 + (spline_matrix(2:end,2)-spline_matrix(1:end-1,2)).^2;
%     arc_coord = [0;cumsum(local_arc_elements)];
%     
%    %%get global worm parameters 
%     wormlength(i) = sum(local_arc_elements); %%total spline length
%     [pks,locs,w,p] = findpeaks(-spline_matrix(:,3),arc_coord);
%     
%     neckwidth(i) = -max(pks);
%     necklength(i) = max(w(pks==max(pks)));
%     
%     i=i+1;
% end

   % plot edge distances over the interval [0,1];
   
   
    %h = figure('visible','off');
    if(filenumber ==1)
    plot(curve_coord,spline_matrix(:,3)./22.92,'-b','LineWidth',1.5); 
    else
    plot(curve_coord,spline_matrix(:,3)./22.92,'-k','LineWidth',1.5);
    end
    
    xlabel('Normalized Length','Fontsize',25,'Fontweight','bold');
    ylabel('Local width (mm)','Fontsize',25,'Fontweight','bold');
    %title(num2str(filenumber));
    %xlim([0 1]);
    ylim([0 1]);
    hold on;
%    saveas(h,[erase(filename,'.mat') '.png']);
end %%End of creating plots
wormlength = wormlength/22.92;
time = 0:1/3:(length(wormlength)-1)/3;

plot(time,wormlength,'-ok','LineWidth',1.5,'markerfacecolor','k');
  ax = gca;
    ax.FontWeight = 'bold';
    ax.FontSize = 20;
    ax.LineWidth = 1.5;
    
xlabel('Time (min)','Fontsize',25,'Fontweight','bold');
ylabel('Worm length (mm)','Fontsize',25,'Fontweight','bold');

%% Create gif

makegif(imdir,1,'E:\Schmedtia fission\Image analysis','ChangingShape.gif'); %%Add every 5th frame to the gif

    
