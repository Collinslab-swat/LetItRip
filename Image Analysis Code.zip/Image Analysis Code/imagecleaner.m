function [cleanimage r0 c0] = imagecleaner(rawimage,window,threshold,areafilter)
        figure(1); imshow(rawimage) %displays first image
        [c0,r0] = ginput(1); r0=round(r0); c0=round(c0);% row/column, origin in upper left corner, ginput works on the figure not the image
        imc=255-rawimage; %inverts image for thresholding and tracking
        im_crop = imc((r0-window):(r0+window),(c0-window):(c0+window)); %crops and makes new image
        % im_crop = imresize(im_crop,4,'bilinear'); %interpolates the image
        figure(2); imshow(im_crop); %displays cropped image
        
        new_im     = imbinarize(im_crop,threshold); %threshold cropped image using originally defined threshold
        figure(3); imshow(new_im); %displays cropped thresholded image
        
        bw = bwareaopen(new_im,areafilter); %get rid of small junk
        bw = imfill(bw,'holes'); %fill holes in worm == eyes
        % figure(4); imshow(bw); %displays cropped thresholded image after area filter was applied
        h = fspecial('disk',5); %filter to smoothen outline and remove small kinks in body shape
        cleanimage = imfilter(bw,h);
        
        figure(4); imshow(cleanimage); %displays cropped thresholded image after area and gauss filter was applied
end
