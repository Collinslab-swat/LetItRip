%% This script reads the .mat files in the folder spit out by the Wormprocessor code.
%%The mat file contains the x,y coordinates of the spline (ordered head to tail)
%%and corresponding distances to the boundary in pixels. These are stored in a 3
%%column matrix named 'spline_matrix'
%%Code starts from the last frame before fracture and identifies the neck
%%of the worm. To identify the neck:
%%The distance to the edge is written as a function of the arc length starting from 
%%the head. The neck is identified as the most prominent valley of this curve.
%%The neck length is the watershed region of the valley and the width of the neck 
%%is the depth of the valley.
%%Written: July15th 2020, Tapan Goel. Modified from matfileprocessor.m
%%Modified: June 25th 2020, Tapan Goel

clear all; clc; clf; close all;

%% Read all .tif file names

%define where to start looking for files
impath = 'E:\Schmedtia fission\Image analysis';
imdir = uigetdir(impath, 'image folder to read');  %this folder should contain all .mat files you want to analyze
cd(imdir);  %switch to folder containing files.
files = dir('*.mat');

cd('E:\Schmedtia fission\Image analysis'); %go back to folder containing all the scripts

%% Enter analysis parameters and length and time scales.
prompt = {'Start Frame:','End Frame:','Gap:','FrameRate(fps):','Scale(pix_per_mmm):','Fracture frame #:'};
dlg_title = 'Settings';
num_lines = 1;
def = {'1',num2str(length(files)),'1','0.9','20',num2str(length(files))};
answer = inputdlg(prompt,dlg_title,num_lines,def);

StartFrame = str2double(answer(1)); %cropping window size; needs to be specified manually; set to zero if you dont want to crop image
EndFrame = str2double(answer(2)); % threshold value
Gap = str2double(answer(3)); % area filter size
FrameRate = str2double(answer(4));
PixPerMm = str2double(answer(5));
FractureFrame = str2double(answer(6));
FrameSeries = EndFrame:-Gap:StartFrame;
index = 0;
necklength = zeros(length(FrameSeries),1);
neckwidth = zeros(length(FrameSeries),1);
%% Process files
for filenumber = EndFrame:-Gap:StartFrame
   index = index + 1; 
   filename = [files(filenumber).folder '\' files(filenumber).name];
   load(filename,'spline_matrix');
   spline_matrix = spline_matrix/PixPerMm;
    
    %%parameterize spline by arclength
    local_arc_elements = (spline_matrix(2:end,1)-spline_matrix(1:end-1,1)).^2 + (spline_matrix(2:end,2)-spline_matrix(1:end-1,2)).^2;
    arc_coord = [0;cumsum(local_arc_elements)];
    
    edgedistance = spline_matrix(:,3);
    plot(arc_coord,edgedistance);
   
    %% Get neck length and width
    [pks,locs,w,p] = findpeaks(-edgedistance,arc_coord,'SortStr','descend');
    
    neckwidth(i) = -max(pks);
    necklength(i) = max(w(pks==max(pks)));
    
    i=i+1;
end

   %% plot edge distances over the interval [0,1];
   
   
%     %h = figure('visible','off');
%     if(filenumber ==1)
%     plot(curve_coord,spline_matrix(:,3)./22.92,'-b','LineWidth',1.5); 
%     else
%     plot(curve_coord,spline_matrix(:,3)./22.92,'-k','LineWidth',1.5);
%     end
%     
%     xlabel('Normalized Length','Fontsize',25,'Fontweight','bold');
%     ylabel('Local width (mm)','Fontsize',25,'Fontweight','bold');
%     %title(num2str(filenumber));
%     %xlim([0 1]);
%     ylim([0 1]);
%     hold on;
% %    saveas(h,[erase(filename,'.mat') '.png']);
% end %%End of creating plots
% wormlength = wormlength/22.92;
% time = 0:1/3:(length(wormlength)-1)/3;
% 
% plot(time,wormlength,'-ok','LineWidth',1.5,'markerfacecolor','k');
  ax = gca;
    ax.FontWeight = 'bold';
    ax.FontSize = 20;
    ax.LineWidth = 1.5;
%     
% xlabel('Time (min)','Fontsize',25,'Fontweight','bold');
% ylabel('Worm length (mm)','Fontsize',25,'Fontweight','bold');
% 
% %% Create gif

%makegif(imdir,1,'E:\Schmedtia fission\Image analysis','ChangingShape.gif'); %%Add every 5th frame to the gif

    
