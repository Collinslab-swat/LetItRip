%% function takes in a grayscale image (the first image of the sequence) and
%%gets windowsize, greythreshold and area filter from the user,
%%converts the image to binary and outputs the ordered coordinates of the midline points 
%%and the corresponding distances to the boundary of the worm of interest
%%defined by the user along with coordinates of its head.


%%Written: June 3rd 2020, Tapan Goel
%%Modified: June 11th 2020, Tapan Goel
%%Modified: July 6th 2020, Tapan Goel - integrated the longestconstrained
%%path function to reliably remove spurs from skeleton.Check rednotebook
%%entry for more notes


function [first_spline_matrix COM_coordinates worm_area first_headcoordinates windowsize threshold areafilter] = ...
                        singleworm_firstframe_processor(rawimage);
                    
    flag_satisfiedparam =0;
while (flag_satisfiedparam==0)  % loops till the correct worm has been identified and the correct parameter values have been found.
    
    flag_frameparam = 0;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    while (flag_frameparam==0) %%loops till correct parameters for cropping frame, thresholding etc are found.
        
        %------- adjustable variables------------------------------------------
        
        prompt = {'enter cropping window size (0 for no crop):','enter threshold value:','enter area filter size:'};
        dlg_title = 'settings';
        num_lines = 1;
        def = {'0','0.6','40'};
        answer = inputdlg(prompt,dlg_title,num_lines,def);
      
        windowsize = str2double(answer(1)); %cropping window size; needs to be specified manually; set to zero if you dont want to crop image
        threshold = str2double(answer(2)); % threshold value
        areafilter = str2double(answer(3)); % area filter size
        
        %--------------------------------------------------------------------------
        figure(1); imshow(rawimage) %displays raw image
        [c0,r0] = ginput(1); r0=round(r0); c0=round(c0);%asks you to pick coordinates of 'center' of worm of interest...
        %origin in upper left corner, ginput works on the figure not the
        %image.
        
        imc=255-rawimage; %inverts image for thresholding and tracking
        
        if(windowsize > 0)
        im_crop = imc((r0-windowsize):(r0+windowsize),(c0-windowsize):(c0+windowsize)); %crops and makes new image
        % im_crop = imresize(im_crop,4,'bilinear'); %interpolates the image
        figure(2); imshow(im_crop); %displays cropped image
        else 
        im_crop = imc;
        end
        
        new_im     = imbinarize(im_crop,threshold); %threshold cropped image using originally defined threshold
        figure(3); imshow(new_im); %displays cropped thresholded image
        
        bw = bwareaopen(new_im,areafilter); %get rid of small junk
        bw = imfill(bw,'holes'); %fill holes in worm == eyes
        % figure(4); imshow(bw); %displays cropped thresholded image after area filter was applied
        h = fspecial('disk',5); %define filter to smoothen outline and remove small kinks in body shape
        bw2 = imfilter(bw,h);%apply filter to smoothen outline and remove small kinks in body shape
        
        figure(4); imshow(bw2); %displays cropped thresholded image after area and gauss filter was applied
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
        %----------------------------------------------------------------
        % construct a question, questdlg, with three options
        
        choice1 = questdlg('Are the initial settings good?','settings','yes','no','yes');
        % handle response
        switch choice1
            case 'yes'
                flag_frameparam = 1;
            case 'no'
                flag_frameparam = 0;
        end
        
        figure(4); imshow(bw2); %displays cropped thresholded image after area and gauss filter was applied
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Now identify objects (worms) in the image and eliminate all worms
        % from the tracking that are not the worm of interest
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    flag_idworm = 0;
    
    while (flag_idworm==0)
        %----------------------------------------------------------------------
        cc = bwconncomp(bw2); %find connected components in image to identify worms
        L = labelmatrix(cc); %create label matrix
        RGB_label = label2rgb(L, @copper, 'c', 'shuffle'); %create pseudocolored image to show connected components
        
        figure(3); imshow(RGB_label,'InitialMagnification','fit') %display the pseudocolor image
        [c0mainwormcom,r0mainworm] = ginput(1); r0mainworm=round(r0mainworm); c0mainwormcom=round(c0mainwormcom);
        % row/column, origin in upper left corner, ginput works on the
        % figure not the image. choose COM of worm of interest
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % construct a question, questdlg, with three options
        choice2 = questdlg('Have you defined the center of mass of the worm to be tracked?','settings','yes','no','yes');
        % handle response
        switch choice2
            case 'yes'
                flag_idworm = 1;
            case 'no'
                flag_idworm = 0;
        end
    end
    
    stats   = regionprops(L, 'centroid', 'area'); %finds centroid and area of all worms
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %----------------------------------------------------------------------
    %if there is more than one object in the image, one must sort out the
    %worm
    %----------------------------------------------------------------------
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if cc.NumObjects > 1 %%if number of recognized worms > 1
        
        worm_distance=zeros(cc.NumObjects,1); %preallocate for distance between center of chosen worm and all worms determined by region props
        worm_com=zeros(cc.NumObjects,2); %preallocate for COM
        
        for j=1:cc.NumObjects
            
            worm_com(j,:)    = stats(j).Centroid; %saves centroid of all worm            
            worm_distance(j)=sqrt((worm_com(j,1)-c0mainwormcom).^2+(worm_com(j,2)-r0mainworm).^2); 
        
        end
        
        id=find(worm_distance==min(worm_distance)); %find array ID of worm of interest
        COM_coordinates=worm_com(id,:); %redefine the center of mass of the worm to be tracked
        worm_area = stats(id).Area; %%assign area of worm
        %% isolate the worm to be tracked from the rest
        worm = false(size(bw2));
        worm(cc.PixelIdxList{id}) = true;
        figure(5); imshow(worm);
      
    elseif cc.NumObjects <=1 %%if there is only one worm
        worm=bw2;
        figure(5); imshow(worm);
        COM_coordinates = stats.Centroid;
        worm_area = stats.Area;
        % com(i-start+1,:)    = stats.Centroid;
    end
    
    choices = questdlg('Are you satisfied with the tracking settings','settings','yes','no','yes');
    % handle response
    switch choices
        case 'yes'
            flag_satisfiedparam = 1;
        case 'no'
            flag_satisfiedparam = 0;
    end %switch end
    
end 

    %% Now that the worm of interest has been isolated, generate the skeleton,head and distance matrix for the worm.
     %%Generate skeleton and distance matrix
     midline = bwskel(worm); %generates a matrix with only the midline
     distancematrix = bwdist(~worm); %generates a distance matrix of distance of each pixel to the nearest boundary pixel for points in the body interior
     midline_distances = distancematrix.*single(midline); %leaves only distances between midline and edge points as non-zero
     
    [midline_ycoord midline_xcoord midline_distances] = find(distancematrix.*single(midline)); %note that row numbers are y coordinates and col numbers are x coordinates.
    
    %%organize the matrix from head to foot.
        %%Identify head of the animal
        [headtail_ycoords headtail_xcoords] = find(bwmorph(longestConstrainedPath(midline),'endpoints'));
        
%         if(length(headtail_ycoords)>2) %%if more than two end points are detected by the image, return to parent function.
%             return
%         end
        
        
        pseudo_color_skeleton = label2rgb(midline, @copper, 'c', 'shuffle'); %create pseudocolored image to show connected components
        figure(6); imshow(pseudo_color_skeleton,'InitialMagnification','fit') %display the pseudocolor image
        [xcoord_closehead,ycoord_closehead] = ginput(1);
        
        temp_ycoords = headtail_ycoords-ycoord_closehead;
        temp_xcoords = headtail_xcoords-xcoord_closehead;
        
        if(norm([temp_xcoords(1) temp_ycoords(1)]) < norm([temp_xcoords(2) temp_ycoords(2)]))
            first_headcoordinates = [headtail_xcoords(1) headtail_ycoords(1)];
        else
            first_headcoordinates = [headtail_xcoords(2) headtail_ycoords(2)];
        end
        
        %%organize the matrix from head to tail
        first_spline_matrix = splinesorter(midline_xcoord,midline_ycoord,midline_distances,first_headcoordinates(1),first_headcoordinates(2));
        

end %function end
