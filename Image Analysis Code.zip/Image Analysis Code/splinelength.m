function length = splinelength(spline_matrix)
    [r c] = size(spline_matrix);
    xcoord = spline_matrix(:,1);
    ycoord = spline_matrix(:,2);
    x_disp = xcoord(2:r)-xcoord(1:(r-1));
    y_disp = ycoord(2:r)-ycoord(1:(r-1));
    
    dist = sqrt(x_disp.*x_disp + y_disp.*y_disp);
    length = sum(dist);
end