%% function takes in x,y coordinates of spline points, the corresponding edge distances and the coordinates of the head as input
%%and returns a Nx3 matrix of the coordinates of spline and corresponding
%%edge distances ordered from head to foot.

%%Written: May 28th 2020, Tapan Goel
%%Modified: May 28th 2020, Tapan Goel

function midline_sorted = splinesorter(midline_x,midline_y,midline_distance,head_x,head_y)

    
    midline_unsorted = zeros(length(midline_x),3);
    midline_unsorted(:,1) = midline_x;
    midline_unsorted(:,2) = midline_y;
    midline_unsorted(:,3) = midline_distance;
    
    midline_sorted = zeros(length(midline_x),3);
    
    
    midline_sorted(1,:) = midline_unsorted(midline_unsorted(:,1) == head_x & midline_unsorted(:,2) == head_y,:);
    midline_unsorted(find((midline_unsorted(:,1) == head_x) & (midline_unsorted(:,2) == head_y)),:) = [];
    
    for sorted_index =  2:1:length(midline_sorted(:,1))
        IDx = 1;  %%Index of neighbour point of interest in the unsorted list
        d_min = 10; %%distance between current sorted point and the following unsorted point
        for unsorted_index = 1:1:length(midline_unsorted(:,1))
            vec = [midline_sorted(sorted_index-1,1)-midline_unsorted(unsorted_index,1);midline_sorted(sorted_index-1,2)-midline_unsorted(unsorted_index,2)];
            
            if d_min > norm(vec) 
                d_min = norm(vec);
                IDx  = unsorted_index;
            end
        end
        midline_sorted(sorted_index,:) = midline_unsorted(IDx,:);
        midline_unsorted(IDx,:) = [];
    end
    
    
end
