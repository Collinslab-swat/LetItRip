%% This script reads the .mat files in the folder spit out by the Wormprocessor code.
%%The mat file contains the x,y coordinates of the spline (ordered head to tail)
%%and corresponding distances to the boundary in pixels. These are stored in a 3
%%column matrix named 'spline_matrix'.
%%The code asks you to navigate to the movie folder, specify the range of
%%folders to analyze, framerate and scalebar.
%%The code then calculates the worm length, worm area,longitudinal strain and areastrain in each frame,
%%saves the info into a summary xls file and generates corresponding time
%%plots.

%%Written: July 11th 2020, Tapan Goel

clear all; clc; clf; close all;

%% Define where to start looking for files.
impath = 'D:\Fission overflow\Tigrina2020';
imdir = uigetdir(impath, 'image folder to read');  %this folder should contain all .mat files you want to analyze
cd(imdir);  %switch to folder containing files.
files = dir('*.mat');
cd('E:\Schmedtia fission\Image analysis'); %go back to folder containing all the scripts

%% Enter analysis parameters and length and time scales.
prompt = {'Start Frame:','End Frame:','Gap:','FrameRate(fps):','Scale(pix_per_mmm):','Fracture frame #:'};
dlg_title = 'Settings';
num_lines = 1;
def = {'1',num2str(length(files)),'1','10','20',num2str(length(files))};
answer = inputdlg(prompt,dlg_title,num_lines,def);

StartFrame = str2double(answer(1)); %cropping window size; needs to be specified manually; set to zero if you dont want to crop image
EndFrame = str2double(answer(2)); % threshold value
Gap = str2double(answer(3)); % area filter size
FrameRate = str2double(answer(4));
PixPerMm = str2double(answer(5));
FractureFrame = str2double(answer(6));
FrameSeries = StartFrame:Gap:EndFrame;

%% Initialize vectors to store time variables
WormLength = zeros(length(FrameSeries),1);
WormArea = zeros(length(FrameSeries),1);
LongStrain = zeros(length(FrameSeries)-1,1);
AreaStrain = zeros(length(FrameSeries)-1,1);
time = zeros(length(FrameSeries)-1,1);
RefLength = 0;
RefArea = 0;

%% Process files
filename1 = [files(StartFrame).folder '\' files(StartFrame).name];
StartNumber = str2num(erase(files(StartFrame).name,["frame", ".mat"]));
for filenumber = StartFrame:Gap:EndFrame
   
   filename = [files(filenumber).folder '\' files(filenumber).name];
   load(filename,'spline_matrix');
   DeltaFrameNumber = str2num(erase(files(filenumber).name,["frame", ".mat"]))-StartNumber;
   time(filenumber) = DeltaFrameNumber/FrameRate;
   spline_matrix = spline_matrix./PixPerMm; %Convert pixels to mm.
   
   %Calculate local arc elements and local area;
   LocalArcElement = sqrt((spline_matrix(2:end,1)-spline_matrix(1:end-1,1)).^2 + (spline_matrix(2:end,2)-spline_matrix(1:end-1,2)).^2);
   LocalAreaElement = 2*(0.5*(spline_matrix(1:(end-1),3) + spline_matrix(2:end,3)).*LocalArcElement);%Using Trepezoid area.The factor 2 accounts for the symmetry about the midline
   
   WormLength(filenumber) = sum(LocalArcElement);
   WormArea(filenumber) = sum(LocalAreaElement);
   
   if(filenumber == 1)
       RefLength = WormLength(filenumber);
       RefArea = WormArea(filenumber) ;
   end
   
   LongStrain(filenumber) = WormLength(filenumber)/RefLength-1;
   AreaStrain(filenumber) = WormArea(filenumber)/RefArea - 1;
  
end

%% Save and plot data
time = time-max(time); %%Time before fracture is measured as negative

FullData = table(time,WormLength,WormArea,LongStrain,AreaStrain,'VariableNames',{'Time_s','Length_mm','Area_sqmm','LinearStrain','AreaStrain'});

writetable(FullData,[imdir '.xlsx']);

   %% plot edge distances over the interval [0,1];
   
   
%     %h = figure('visible','off');
%     if(filenumber ==1)
%     plot(curve_coord,spline_matrix(:,3)./22.92,'-b','LineWidth',1.5); 
%     else
%     plot(curve_coord,spline_matrix(:,3)./22.92,'-k','LineWidth',1.5);
%     end
%     
%     xlabel('Normalized Length','Fontsize',25,'Fontweight','bold');
%     ylabel('Local width (mm)','Fontsize',25,'Fontweight','bold');
%     %title(num2str(filenumber));
%     %xlim([0 1]);
%     ylim([0 1]);
%     hold on;
% %    saveas(h,[erase(filename,'.mat') '.png']);
% end %%End of creating plots
% wormlength = wormlength/22.92;
% time = 0:1/3:(length(wormlength)-1)/3;
% 
% plot(time,wormlength,'-ok','LineWidth',1.5,'markerfacecolor','k');
%   ax = gca;
%     ax.FontWeight = 'bold';
%     ax.FontSize = 20;
%     ax.LineWidth = 1.5;
% %     
% xlabel('Time (min)','Fontsize',25,'Fontweight','bold');
% ylabel('Worm length (mm)','Fontsize',25,'Fontweight','bold');
% 
% %% Create gif

%makegif(imdir,1,'E:\Schmedtia fission\Image analysis','ChangingShape.gif'); %%Add every 5th frame to the gif

    
