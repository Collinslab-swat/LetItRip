%% function takes in a grayscale image, windowsize, greythreshold and area filter as input
%%converts it to binary and outputs the clean BW image, a binary image with the midline as ones...
%%ordered coordinates of the midline points and the corresponding distances to the boundary.
%%Modified the singleworm_singleframe_roi script to create a new script singleworm_singleframe_roi
%%which also takes the roi specified in the previous image as the ROI for the next image.
%%This is useful when two worms overlap over multiple frames but dont change position too much.
%%The code displays every new ROI image and asks you if the new ROI is okay after every 10th image. 
%%If you say no, it asks you to pick a new ROI and iterates further.

%%Written: July 8th 2020, Tapan Goel - modified from the
%%singleworm_singleframe_processor script
%%Modified: July 8th 2020, Tapan Goel - integrated the longestconstrained
%%path function to reliably remove spurs from skeleton.Check rednotebook
%%entry for more notes.
%%Modified: July 6th 2020, Tapan Goel - changed bwskel to bwmorph(thin)
%%Modified: July 8th 2020, Tapan Goel - added imageanalysischecking at for every
%%10th image (at the end of code)
function [spline_matrix, COMcoordinates, worm_area, headcoordinates newroi] = singleworm_singleframe_roi_processor_loops(rawimage,oldCOM,oldarea,oldhead,windowsize,threshold,areafilter,oldroi,filenumber);
        

        
        %% cleanup image
        imc=255-rawimage; %inverts image for thresholding and tracking
        
        if(windowsize > 0)
        im_crop = imc((oldCOM(2)-windowsize):(oldCOM(2)+windowsize),(oldCOM(1)-windowsize):(oldCOM(1)+windowsize)); %crops and makes new image     
        else 
        im_crop = imc;
        end
        
        new_im = imbinarize(imc,threshold); %threshold cropped image using originally defined threshold
        bw = bwareaopen(new_im,areafilter); %get rid of small junk
        bw = imfill(bw,'holes'); %fill holes in worm == eyes
        h = fspecial('disk',3); %filter to smoothen outline and remove small kinks in body shape
        cleanimage = imfilter(bw,h);
        
        %% identify all worms
        cc1 = bwconncomp(cleanimage); %find connected components in image to identify worms
        L = labelmatrix(cc1); %create label matrix
        stats   = regionprops(L, 'centroid', 'area'); %finds centroid and area of all worms
        
        %% identify worm of interest
        
        if cc1.NumObjects == 1   %%if there is only one object identified (which is the worm)
            
            worm_area = stats.Area;
            %% Only one worm and area within range
            if((worm_area > 0.9*oldarea) & (worm_area < 1.1*oldarea)) %%check the worm area does not change dramatically
            newroi = oldroi;    
            COMcoordinates = stats.Centroid;
            worm = cleanimage;
            midline = longestConstrainedPath(longestConstrainedPath(bwmorph(imfill(bwmorph(worm,'thin',inf),'holes'),'thin',inf))); %generates a matrix with only the midline
            distancematrix = bwdist(~worm); %generates a distance matrix of distance of each pixel to the nearest boundary pixel for points in the body interior
            midline_distances = distancematrix.*single(midline); %leaves only distances between midline and edge points as non-zero
           [midline_ycoord midline_xcoord midline_distances] = find(distancematrix.*single(midline)); %note that row numbers are y coordinates and col numbers are x coordinates.
           %%organize the matrix from head to foot.
           %%Identify head of the animal
           [headtail_ycoords headtail_xcoords] = find(bwmorph(midline,'endpoints'));;
            if(length(headtail_ycoords)>2) %%if more than two end points are detected by the image, return to parent function.
                figure;imshow(wormimage-cleanskeletonimage);
                hold on;
                scatter(endpointsx,endpointsy,'*');
            end
            temp_ycoords = headtail_ycoords-oldhead(2);
            temp_xcoords = headtail_xcoords-oldhead(1);

            if(norm([temp_xcoords(1) temp_ycoords(1)]) < norm([temp_xcoords(2) temp_ycoords(2)]))
                headcoordinates = [headtail_xcoords(1) headtail_ycoords(1)];
            else
                headcoordinates = [headtail_xcoords(2) headtail_ycoords(2)];
            end
            
            spline_matrix = splinesorter(midline_xcoord,midline_ycoord,midline_distances,headcoordinates(1),headcoordinates(2));
            %% Only one worm but area out of range - need to identify worm manually
            
            
            else  %%if the worm area changes dramatically (and only one object has been identified, ie. some new shit is identified with the worm
                %% Plug code for manual mode
                %%Find ROI
                if(oldroi == 0) %%If there is no old ROI
                    figure;gcf.WindowState = 'maximized'; newroi=roipoly(cleanimage);close gcf;                
                    worm = false(size(cleanimage));
                    worm(newroi) = true;
                    worm = imbinarize(worm.*cleanimage);
                    figure;imshow(worm);gcf.WindowState = 'maximized';pause(0.5); close gcf; 
                else %%If there is an old ROI
                    newroi=oldroi;
                    worm = false(size(cleanimage));
                    worm(newroi) = true;
                    worm = imbinarize(worm.*cleanimage);
                    figure;imshow(worm);gcf.WindowState = 'maximized';
                    if(mod(filenumber,10)==0)
                    choice1 = questdlg('Is ROI good?','settings','yes','no','yes');
                    % handle response
                    switch choice1
                        case 'yes'
                            newroi = oldroi;
                            close gcf;
                        case 'no'
                            figure;gcf.WindowState = 'maximized'; newroi=roipoly(cleanimage);close gcf;                
                            worm = false(size(cleanimage));
                            worm(newroi) = true;
                            worm = imbinarize(worm.*cleanimage);
                            figure;imshow(worm);gcf.WindowState = 'maximized';pause(0.5); close gcf; 
                    end
                    end
                end
                
                    
               midline = longestConstrainedPath(longestConstrainedPath(bwmorph(imfill(bwmorph(worm,'thin',inf),'holes'),'thin',inf))); %generates a matrix with only the midline
                distancematrix = bwdist(~worm); %generates a distance matrix of distance of each pixel to the nearest boundary pixel for points in the body interior
                midline_distances = distancematrix.*single(midline); %leaves only distances between midline and edge points as non-zero
               [midline_ycoord midline_xcoord midline_distances] = find(distancematrix.*single(midline)); %note that row numbers are y coordinates and col numbers are x coordinates.
               %%organize the matrix from head to foot.
               %%Identify head of the animal
               [headtail_ycoords headtail_xcoords] = find(bwmorph(midline,'endpoints'));;
                if(length(headtail_ycoords)>2) %%if more than two end points are detected by the image, return to parent function.
                    disp('Multiple heads');
                    return
                end
                temp_ycoords = headtail_ycoords-oldhead(2);
                temp_xcoords = headtail_xcoords-oldhead(1);

                if(norm([temp_xcoords(1) temp_ycoords(1)]) < norm([temp_xcoords(2) temp_ycoords(2)]))
                    headcoordinates = [headtail_xcoords(1) headtail_ycoords(1)];
                else
                    headcoordinates = [headtail_xcoords(2) headtail_ycoords(2)];
                end

                spline_matrix = splinesorter(midline_xcoord,midline_ycoord,midline_distances,headcoordinates(1),headcoordinates(2));
                cc1 = bwconncomp(worm); %find connected components in image to identify worms
                L = labelmatrix(cc1); %create label matrix
                stats   = regionprops(L, 'centroid', 'area'); %finds centroid and area of all worms
                COMcoordinates = stats.Centroid;
                worm_area = stats.area;
                
                    
            end %end for single worm - within and outside area range
            
        %% If multiple objects are identified    
        else %% if multiple objects are identified
            
            distancematrix=zeros(cc1.NumObjects,1); %preallocate distance vector for COM distance
            comworms=zeros(cc1.NumObjects,2); %preallocate center of mass coordinates of all objects
            
            for j=1:cc1.NumObjects

                comworms(j,:) = stats(j).Centroid; %saves centroid of all objects that program finds in comw matrix
                distancematrix(j)=sqrt((comworms(j,1)-oldCOM(1)).^2+(comworms(j,2)-oldCOM(2)).^2); %do a comparison of the comw components with the predefined worm coordinates from the first images

            end
            %%Identify ID of the right worm.
            ID=find(distancematrix==min(distancematrix)); %Find ID of worm whose COM is closed to COM of worm of interest in previous frame
            worm_area = stats(ID).Area;
            
            %% IF multiple worms are identified and area is within range
            if((worm_area > 0.9*oldarea) & (worm_area < 1.1*oldarea)) %Area of worm of interest does not change dramatically between frames.
                                                                %Detects shit like worms overlapping or worm being identified with boundary of dish
            newroi = oldroi;
            %% isolate worm of interest. obtain ordered spline, COM coordinates etc.
            COMcoordinates = stats(ID).Centroid;
            worm = false(size(cleanimage));
            worm(cc1.PixelIdxList{ID}) = true;
            midline = longestConstrainedPath(longestConstrainedPath(bwmorph(imfill(bwmorph(worm,'thin',inf),'holes'),'thin',inf))); %generates a matrix with only the midline
            distancematrix = bwdist(~worm); %generates a distance matrix of distance of each pixel to the nearest boundary pixel for points in the body interior
            midline_distances = distancematrix.*single(midline); %leaves only distances between midline and edge points as non-zero
            [midline_ycoord midline_xcoord midline_distances] = find(distancematrix.*single(midline)); %note that row numbers are y coordinates and col numbers are x coordinates.

            %%organize the matrix from head to foot.
            %%Identify head of the animal
            [headtail_ycoords headtail_xcoords] = find(bwmorph(midline,'endpoints'));

            if(length(headtail_ycoords)>2) %%if more than two end points are detected by the image, return to parent function.
                return
            end
            
            temp_ycoords = headtail_ycoords-oldhead(2);
            temp_xcoords = headtail_xcoords-oldhead(1);

            if(norm([temp_xcoords(1) temp_ycoords(1)]) < norm([temp_xcoords(2) temp_ycoords(2)]))
                headcoordinates = [headtail_xcoords(1) headtail_ycoords(1)];
            else
                headcoordinates = [headtail_xcoords(2) headtail_ycoords(2)];
            end
            
            spline_matrix = splinesorter(midline_xcoord,midline_ycoord,midline_distances,headcoordinates(1),headcoordinates(2));
            

    
            else %%else to condition of worm area
                %% Enter code for manual implementation
                if(oldroi == 0) %%If there is no old ROI
                    figure;gcf.WindowState = 'maximized'; newroi=roipoly(cleanimage);close gcf;                
                    worm = false(size(cleanimage));
                    worm(newroi) = true;
                    worm = imbinarize(worm.*cleanimage);
                    figure;imshow(worm);gcf.WindowState = 'maximized';pause(0.5); close gcf; 
                else %%If there is an old ROI
                    newroi=oldroi;
                    worm = false(size(cleanimage));
                    worm(newroi) = true;
                    worm = imbinarize(worm.*cleanimage);
                    figure;imshow(worm);gcf.WindowState = 'maximized';
                    if(mod(filenumber,10)==0)
                    choice1 = questdlg('Is ROI good?','settings','yes','no','yes');
                    % handle response
                    switch choice1
                        case 'yes'
                            newroi = oldroi;
                            close gcf;
                        case 'no'
                            figure;gcf.WindowState = 'maximized'; newroi=roipoly(cleanimage);close gcf;                
                            worm = false(size(cleanimage));
                            worm(newroi) = true;
                            worm = imbinarize(worm.*cleanimage);
                            figure;imshow(worm);gcf.WindowState = 'maximized';pause(0.5); close gcf; 
                    end
                    end
                end
                
                midline = longestConstrainedPath(longestConstrainedPath(bwmorph(imfill(bwmorph(worm,'thin',inf),'holes'),'thin',inf)));; %generates a matrix with only the midline
                distancematrix = bwdist(~worm); %generates a distance matrix of distance of each pixel to the nearest boundary pixel for points in the body interior
                midline_distances = distancematrix.*single(midline); %leaves only distances between midline and edge points as non-zero
               [midline_ycoord midline_xcoord midline_distances] = find(distancematrix.*single(midline)); %note that row numbers are y coordinates and col numbers are x coordinates.
               %%organize the matrix from head to foot.
               %%Identify head of the animal
               [headtail_ycoords headtail_xcoords] = find(bwmorph(midline,'endpoints'));;
                if(length(headtail_ycoords)>2) %%if more than two end points are detected by the image, return to parent function.
                    disp('Multiple heads');
                    return
                end
                temp_ycoords = headtail_ycoords-oldhead(2);
                temp_xcoords = headtail_xcoords-oldhead(1);

                if(norm([temp_xcoords(1) temp_ycoords(1)]) < norm([temp_xcoords(2) temp_ycoords(2)]))
                    headcoordinates = [headtail_xcoords(1) headtail_ycoords(1)];
                else
                    headcoordinates = [headtail_xcoords(2) headtail_ycoords(2)];
                end

                spline_matrix = splinesorter(midline_xcoord,midline_ycoord,midline_distances,headcoordinates(1),headcoordinates(2));
                cc1 = bwconncomp(worm); %find connected components in image to identify worms
                L = labelmatrix(cc1); %create label matrix
                stats   = regionprops(L, 'centroid', 'area'); %finds centroid and area of all worms
                COMcoordinates = stats.Centroid;
                worm_area = stats.Area;

               
            end %% end of if statement on worm area
            
        end

        close all;
        
        %% Check every 10th frame for correctness of analysis
        if(mod(filenumber,10)==0)
        allgood = ImageAnalysisChecker(rawimage,worm,midline,headtail_xcoords,headtail_ycoords);
        end
end %end of function
