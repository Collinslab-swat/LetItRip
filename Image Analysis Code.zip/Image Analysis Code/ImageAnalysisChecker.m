%% function takes in rawimage, clean binaryimage, the skeleton and its end points.
%%Displays those images and asks for confirmation that the analysis is
%%correct. If correct, things continue. If not, the function returns to
%%main code and will give error;

%%Written: July 8th 2020, Tapan Goel 
function allgood = ImageAnalysisChecker(rawimage,wormimage,cleanskeletonimage,endpointsx,endpointsy)

    figure;imshow(rawimage);
    figure;imshow(wormimage-cleanskeletonimage);
    hold on;
    scatter(endpointsx,endpointsy,'*');
    
    pause(2);
    
    allgood = questdlg('Quality Check: Is the ROI good?','settings','yes','no','yes');
                    % handle response
                    switch allgood
                        case 'yes'
                            %newroi = oldroi;
                            close all;
                        case 'no'
                            disp('Image analysis Failure');
                            exit();
                    end
    

end
