%% This script reads the .tif images in the folder.
%%It takes the first image, processes it and checks if the processing is correct
%%Once it determines that the processing is correct, it generates the
%%spline and asks you to define the head of the worm on the
%%spline. It then saves the coordinates of the spline along with the
%%distances to the edge in a .mat file, sorted from head to tail.
%%for succeding images, the code uses the processing parameters from the
%%first image and generates the spline,distances and end points. The head is
%%identified as the end point closest to the previous head. The script then
%%sorts the spline from the head to tail and stores the coordinates and
%%distances (in pixels) in a .mat file.

%%Written: June 3rd 2020, Tapan Goel
%%Modified: June 3rd 2020, Tapan Goel

clear all; clc; clf; close all;

%% Read all .tif file names

%define where to start looking for images
impath = 'D:\Fission overflow\2020Japonica'; %%where the folder containing the images is
imdir = uigetdir(impath, 'image folder to read');  %this folder should contain all images you want to analyze
script_location = pwd;
cd(imdir);  %switch to folder containing images.
files = dir('*fig2.jpg');

cd(script_location); %go back to folder containing all the scripts

%% Process images
for filenumber = [1]
    filenumber
   filename = [files(filenumber).folder '\' files(filenumber).name];
   rawimage = imread(filename);
   
   %% Get processing parameters from first frame
   if(filenumber == 1)
       [spline_matrix COMcoordinates worm_area headcoordinates windowsize threshold areafilter] = ...
                        singleworm_firstframe_processor(rawimage);
       save(['D:\Fission overflow\2020Japonica\20210109_7fps_6well_fission\' erase(files(filenumber).name,'.jpg') '.mat'],'spline_matrix');
       newroi = 0;
   else 
   %% process other frames    
    oldCOM = COMcoordinates; %set previous frame COM coordintes and worm area to 'old' since this goes as input for processing current frame number
    oldarea = worm_area;
    oldhead = headcoordinates;
    oldroi = newroi;
    [spline_matrix COMcoordinates worm_area headcoordinates newroi] = singleworm_singleframe_roi_processor(rawimage,oldCOM,oldarea,oldhead,windowsize,threshold,areafilter,oldroi,filenumber);
    
    save(['D:\Fission overflow\2020Japonica\20200901_10fps_6well\Matfile\' erase(files(filenumber).name,'.jpg') '.mat'],'spline_matrix');
    
   
   end %%end of if statement for processing first frame vs other frames
    
end %%end of frame processing loop
    
    