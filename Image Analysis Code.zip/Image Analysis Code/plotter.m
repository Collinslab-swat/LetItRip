%% This script reads all the .xlsx files in the folder containing time,worm length, worm area, linear and areal strains.
%% The script then makes time vs strain plots and saves them to the folder as pngs


%%Written: July 11th 2020, Tapan Goel
%%Modified: Sept 23 2020, Tapan Goel: Added code to plot strain vs time,
%%use brush tool to select data range of interest, fit it to a tanh curve
%%and plot and save the resulting curve and its fit.
clear all; clc; clf; close all;

%% Define where to start looking for files.
impath = 'E:\Fission';
imdir = uigetdir(impath, 'image folder to read');  %this folder should contain all .mat files you want to analyze
cd(imdir);  %switch to folder containing files.
files = dir('*.xlsx');
cd('E:\Fission\Image analysis'); %go back to folder containing all the scripts

mainfig = figure;
ax = gca;
ax.FontWeight = 'bold';
ax.FontSize = 20;
ax.LineWidth = 1.5;

xlabel('Normalized Time','Fontsize',25,'Fontweight','bold','FontName','Arial');
ylabel('Normalized LinearStrain','Fontsize',25,'Fontweight','bold','FontName','Arial');
hold on;
for filenumber = 1:length(files)
   
   filename = [files(filenumber).folder '\' files(filenumber).name];
   data = readtable(filename);
   
   fig = figure;
   plot(data.Time_s(1:end-2),data.LinearStrain(1:end-2));
   
   ax = gca;
   ax.FontWeight = 'bold';
   ax.FontSize = 20;
   ax.LineWidth = 1.5;
   
   xlabel('Time (s)','Fontsize',25,'Fontweight','bold');
   ylabel('LinearStrain','Fontsize',25,'Fontweight','bold');
   
   brush('on');
   pause(15);
   %% Select data points and create variable bdata;
   
   t= bdata(:,1);
   y = bdata(:,2);
   
   %% Define model function and fit curve
   %% Enter guess fit parameters
    prompt = {'Max Strain:','Center Time:','TimeScale:'};
    dlg_title = 'Settings';
    num_lines = 1;
    def = {'1',num2str(length(files)),'1','10','20',num2str(length(files))};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    b0(1) = str2double(answer(1))/2;
    b0(2) = str2double(answer(2));
    b0(3) = str2double(answer(3));
    
   modelfun = @(b,x)b(1)*(1 + tanh((x-b(2))/b(3)));
   
   b = wnlfit(t,y,[],[],modelfun,b0);
   
   Y = b.param(1)*(1 + tanh((t-b.param(2))/b.param(3)));
   fig1 =figure;
   plot(t,y);
   hold on;
   plot(t,Y,'k','Linewidth',1.2);
   title(['a=' num2str(b.param(1),2) '  \tau =' num2str(b.param(3),2)]);
   ax = gca;
   ax.FontWeight = 'bold';
   ax.FontSize = 20;
   ax.LineWidth = 1.5;
   
   xlabel('Time (s)','Fontsize',25,'Fontweight','bold');
   ylabel('LinearStrain','Fontsize',25,'Fontweight','bold');
   %saveas(fig1,[erase(filename,'.xlsx') '-LongStrainFit.png']);
   
   close(fig1);
   close(fig);
   
   %% Add normalized curve to main figure
   mainfig;
   
   t1 = (t-b.param(2))./b.param(3);
   y1 = y./b.param(1);
   plot(t1,smooth(y1,20),'-','LineWidth',1.2,'Color',[.75 .75 .75]);
   
   pause(10);
    
end


%% Save and plot data


   %% plot edge distances over the interval [0,1];
   
   
%     %h = figure('visible','off');
%     if(filenumber ==1)
%     plot(curve_coord,spline_matrix(:,3)./22.92,'-b','LineWidth',1.5); 
%     else
%     plot(curve_coord,spline_matrix(:,3)./22.92,'-k','LineWidth',1.5);
%     end
%     
%     xlabel('Normalized Length','Fontsize',25,'Fontweight','bold');
%     ylabel('Local width (mm)','Fontsize',25,'Fontweight','bold');
%     %title(num2str(filenumber));
%     %xlim([0 1]);
%     ylim([0 1]);
%     hold on;
% %    saveas(h,[erase(filename,'.mat') '.png']);
% end %%End of creating plots
% wormlength = wormlength/22.92;
% time = 0:1/3:(length(wormlength)-1)/3;
% 
% plot(time,wormlength,'-ok','LineWidth',1.5,'markerfacecolor','k');

% 
% %% Create gif

%makegif(imdir,1,'E:\Schmedtia fission\Image analysis','ChangingShape.gif'); %%Add every 5th frame to the gif

    
