% this program does shape tracking of planarians during fission
%--------------------------------------------------------
%last modified by ems, 6/10/2011

%this is a functional version that should work for fission data

% the program allows the user to find the optimal settings in the first
% image and then applies these settings subsequently to the entire image
% sequence

% it tracks the position of the head and tail over time as well as
% reconstructs the entire spline of the worm, allowing for curve fitting to
% be applied later.

%---------------------------------------------------------

clear all; clc; clf; close all;

%---part 1: read and write data ------------------

%define where to start looking for images
impath = 'E:\Schmedtia fission\Image analysis';
imdir = uigetdir(impath, 'image folder to read');  %this folder should contain all images you want to analyze
[filename,pathname] = uigetfile(imdir,'select the first image');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% IMPORTANT: one needs to specify the head and tail points for the worm
% spline on the FIRST image of the sequence, else the tracking with the
% nearest neighbor algorithm won't work
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%MANUAL SPECIFICATION OF START AND END IMAGE FOR A GIVEN SEQUENCE OF INTEREST

%--------------------------------------------------------------------------
start = 0; %this is the start image name of the image sequence where one wants to start the analysis
finish = 1000; %end image name
%-------------------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delta=4; %number of true digits in the filename
front_length = length(filename)-(delta+4);
front = filename(1:front_length);
[no_use1 no_use2 extension] = fileparts(filename);
%image in the folder (which doesn't have to be 1 and thus counting is off)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%-----specifiy save directory and folder ----------------------------------
savepath = 'E:\Schmedtia fission\Image analysis\Analyzed'; cd(savepath);
%where to start looking for a place to save the analyzed data
[savename,savedir] = uiputfile('*.mat','workspace save-name','fission_shape_');
%addpath(fullfile('c:', 'documents and settings','ems', 'my documents','matlab', 'functions')); %add the folder to the path

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
loops =0;
while (loops==0)
    
    loop = 0;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    while (loop==0)
        
        %------- adjustable variables------------------------------------------
        
        prompt = {'enter cropping window size:','enter threshold value:','enter area filter size:'};
        dlg_title = 'settings';
        num_lines = 1;
        def = {'100','0.6','40'};
        answer = inputdlg(prompt,dlg_title,num_lines,def);
      
        w = str2double(answer(1)); %cropping window size; needs to be specified manually;
        thresh = str2double(answer(2)); % threshold value
        af = str2double(answer(3)); % area filter size
        
        %--------------------------------------------------------------------------
        digits = length(num2str(start));
        zz(1:(delta-digits)) = '0';
        file = [front zz num2str(start) extension];
        im    = imread(fullfile(pathname,file)); %this is the start image as specified by Rstart,%nb x and y must be swapped: pixel region is row & column; must be put in manually
        figure(1); imshow(im) %displays first image
        [c0,r0] = ginput(1); r0=round(r0); c0=round(c0);% row/column, origin in upper left corner, ginput works on the figure not the image
        imc=255-im; %inverts image for thresholding and tracking
        im_crop = imc((r0-w):(r0+w),(c0-w):(c0+w)); %crops and makes new image
        % im_crop = imresize(im_crop,4,'bilinear'); %interpolates the image
        figure(2); imshow(im_crop); %displays cropped image
        
        new_im     = imbinarize(im_crop,thresh); %threshold cropped image using originally defined threshold
        figure(3); imshow(new_im); %displays cropped thresholded image
        
        bw = bwareaopen(new_im,af); %get rid of small junk
        bw = imfill(bw,'holes'); %fill holes in worm == eyes
        % figure(4); imshow(bw); %displays cropped thresholded image after area filter was applied
        h = fspecial('disk',5); %filter to smoothen outline and remove small kinks in body shape
        bw2 = imfilter(bw,h);
        
        figure(4); imshow(bw2); %displays cropped thresholded image after area and gauss filter was applied
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %----------------------------------------------------------------
        % construct a question, questdlg, with three options
        
        choice1 = questdlg('Are the initial settings good?','settings','yes','no','yes');
        % handle response
        switch choice1
            case 'yes'
                loop = 1;
            case 'no'
                loop = 0;
        end
        figure(4); imshow(bw2); %displays cropped thresholded image after area and gauss filter was applied
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Now identify objects (worms) in the image and eliminate all worms
        % from the tracking that are not the worm of interest
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
    
    loop2 = 0;
    
    while (loop2==0)
        %----------------------------------------------------------------------
        cc = bwconncomp(bw2); %find connected components in image to identify worm
        L = labelmatrix(cc); %create label matrix
        RGB_label = label2rgb(L, @copper, 'c', 'shuffle'); %create pseudocolored image to show connected components
        
        figure(3); imshow(RGB_label,'InitialMagnification','fit') %display the pseudocolor image
        [c0crop,r0crop] = ginput(1); r0crop=round(r0crop); c0crop=round(c0crop);% row/column, origin in upper left corner, ginput works on the figure not the image
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % construct a question, questdlg, with three options
        choice2 = questdlg('Have you defined the center of mass of the worm to be tracked?','settings','yes','no','yes');
        % handle response
        switch choice2
            case 'yes'
                loop2 = 1;
            case 'no'
                loop2 = 0;
        end
    end
    
    stats   = regionprops(L, 'centroid', 'area'); %finds centroid and area of all worms
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %----------------------------------------------------------------------
    %if there is more than one object in the image, one must sort out the
    %worm
    %----------------------------------------------------------------------
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if cc.NumObjects > 1
        
        dbcom=zeros(cc.NumObjects,1); %preallocate for speed
        comw=zeros(cc.NumObjects,2); %preallocate for speed
        
        for j=1:cc.NumObjects
            
            comw(j,:)    = stats(j).Centroid; %saves centroid of all objects that program finds in comw matrix
            
            %now use a nearest neighbor algorithm to determine the worm that is
            %supposed to be tracked
            dbcom(j)=sqrt((comw(j,1)-round(c0crop)).^2+(comw(j,2)-round(r0crop)).^2); %do a comparison of the comw components with the predefined worm coordinates from the first images
        end
        Mincom=min(dbcom); %this is the nearest neighbor
        id=find(dbcom==Mincom);
        com_t=comw(id,:); %redefine the center of mass of the worm to be tracked
        
        %isolate the worm to be tracked from the rest
        worm = false(size(bw2));
        worm(cc.PixelIdxList{id}) = true;
        figure(5); imshow(worm);
        A0worm0 = stats(id).Area; %area of worm in first image
    elseif cc.NumObjects <=1
        worm=bw2;
        figure(5); imshow(worm);
        A0worm0 = stats.Area;
        com_t = stats.Centroid;
        % com(i-start+1,:)    = stats.Centroid;
    end
    
    choices = questdlg('Are you satisfied with the tracking settings','settings','yes','no','yes');
    % handle response
    switch choices
        case 'yes'
            loops = 1;
        case 'no'
            loops = 0;
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%---------------close all figures------------------------------------------
close(figure(1));
close(figure(2));
close(figure(3));
close(figure(4));
close(figure(5));

%%%%%%%%%%%% end cropping & thresholding part %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%---------------this part extracts the worm spline


findspline =0;
while (findspline == 0)
    
    bw3 = bwmorph(worm, 'thin', inf);
    figure(2); imshow(bw3); [t0,b0] = ginput(2); %manually define the head (1) and tail (2) in the first image by clicking on it.
    % construct a question, questdlg, with three options
    hold on; plot(t0(1),b0(1), 'r*'); plot(t0(2),b0(2), 'y*'); %plot head and tail points
    choice = questdlg('Are the spline settings good?','settings','yes','no','yes');
    % handle response
    switch choice
        case 'yes'
            findspline = 1;
        case 'no'
            findspline = 0;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%---------------close all figures------------------------------------------

close(figure(1));
close(figure(2));
close(figure(3));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now all the settings should be optimized for only tracking the worm of
% interest while it is fissioning and not other worms that may be present
% in the first image.
%When going through the entire image sequence now, what may happen is that
%additional worms show up and run through the ROI and possibly even cross
%the worm; these worms need to be eliminated.
%to achieve clean tracking, we will use both the COM nearest neighbor
%procedure employed above and an area filter, ergo when the area of the
%object to be tracked changes to dramatically, we will switch to 'manual
%mode'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The key will be to introduce a part here that looks for the number of
% objects in each frame and then only processes the original worm and is
% able to distinguish between objects.


all =1; %set to one if you want to run the program for all images files

if all ==1
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    clear x y stats
    
    x=zeros(finish-start+1,1);  %pre-allocate space for matrices to speed up program
    y=zeros(finish-start+1,1);
    com=zeros(finish-start+1,2);
    wormArea=zeros(finish-start+1,1);
    head=zeros(finish-start+1,2);
    tail=zeros(finish-start+1,2);
    nb=zeros(finish-start+1,2);
    nt=zeros(finish-start+1,2);
    com2=zeros(finish-start+1,2);
    tx1=zeros(finish-start+1,1);
    hx1=zeros(finish-start+1,1);
    ty1=zeros(finish-start+1,1);
    hy1=zeros(finish-start+1,1);
    
    Aiworm = A0worm0;
    A0worm = A0worm0;
    find_tail = 0;
    findspline = 0;
    brk = finish;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    while (Aiworm>= 0.9*A0worm0)
        
        for i = start:finish;
            
            i
            digits = length(num2str(i));
            zz(1:(delta-digits)) = '0';
            file = [front zz num2str(i) extension];
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            cd(imdir); im = imread(file);
            wold = w; dimr = size(im, 1); dimc = size(im, 2);
            r   = r0;   c   = c0; %start with coordinates that were defined in first image; %now x and y are row&column indices
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %--- avoid ROI exiting image ---
            if r - w < 1; r = w + 1;
            elseif r + w > dimr; r = dimr - w;
            elseif c - w < 1; c = w + 1;
            elseif c + w > dimc; c = dimc - w;
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            imc = 255-im;
            im_crop = imc((r-w):(r+w),(c-w):(c+w)); %crops and makes new image
            new_im     = im2bw(im_crop,thresh); %threshold cropped image using originally defined threshold
            bw = bwareaopen(new_im,af); %get rid of small junk
            bw = imfill(bw,'holes'); %fill holes in worm == eyes
            h = fspecial('disk',5); %filter to smoothen outline and remove small kinks in body shape
            bw2 = imfilter(bw,h);
            %-------------------------------------------------------------
            %label image objects (worm)
            cc = bwconncomp(bw2); %find connected components in image to identify worm
            L = labelmatrix(cc); %create label matrix
            
            stats   = regionprops(L, 'centroid', 'area'); %finds centroid and area of all worms
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            if cc.NumObjects > 1
                
                dbcom=zeros(cc.NumObjects,1); %preallocate for speed
                dbcom2=zeros(cc.NumObjects,1); %preallocate for speed
                comw=zeros(cc.NumObjects,2); %preallocate for speed
                
                for j=1:cc.NumObjects
                    
                    
                    comw(j,:)    = stats(j).Centroid; %saves centroid of all objects that program finds in comw matrix
                    
                    %now use a nearest neighbor algorithm to determine the worm that is
                    %supposed to be tracked
                    if (i-start==0)
                        dbcom(j)=sqrt((comw(j,1)-com_t(1,1)).^2+(comw(j,2)-com_t(1,2)).^2); %do a comparison of the comw components with the predefined worm coordinates from the first images
                    elseif (i-start >=1)
                        dbcom(j)=sqrt((comw(j,1)-com(i-start,1)).^2+(comw(j,2)-com(i-start,2)).^2); %compare coms with com from previous image
                        % dbcom(j)=sqrt((comw(1,j)-x(i-Rstart,1)).^2+(comw(2,j)-y(i-Rstart,2)).^2);
                    end
                end
                
                Mincom=min(dbcom); %this is the nearest neighbor
                id=find(dbcom==Mincom);
                com(i-start+1,:)=comw(id,:); %redefine the center of mass of the worm to be tracked
                wormArea(i-start+1,:) =stats(id).Area; %area of worm
                %isolate the worm to be tracked from the rest
                Aiworm = wormArea(i-start+1);
                worm = false(size(bw2));
                worm(cc.PixelIdxList{id}) = true;
                if (Aiworm<= 0.9*A0worm)&&(find_tail==0)
                    L = labelmatrix(cc); %create label matrix
                    RGB_label = label2rgb(L, @copper, 'c', 'shuffle'); %create pseudocolored image to show connected components
                    figure(3); imshow(RGB_label,'InitialMagnification','fit') %display the pseudocolor image
                    [ctcrop,rtcrop] = ginput(1); rtcrop=round(rtcrop); ctcrop=round(ctcrop); 
                    brk = i;
                    find_tail = 1;
                    wormArea2=zeros(finish+1-brk,1);
                    head2=zeros(finish+1-brk,2);
                    tail2=zeros(finish+1-brk,2);
                end
                if (Aiworm<= 0.9*A0worm) && (find_tail==1)
                    for j=1:cc.NumObjects
                    %now use a nearest neighbor algorithm to determine the worm that is
                    %supposed to be tracked
                    dbcom2(j)=sqrt((comw(j,1)-round(ctcrop)).^2+(comw(j,2)-round(rtcrop)).^2); %do a comparison of the comw components with the predefined worm coordinates from the first images
                    end
                    Mincom2=min(dbcom2); %this is the nearest neighbor
                    id2=find(dbcom2==Mincom2);
                    com2(i-start+1,:)=comw(id2,:); %redefine the center of mass of the worm to be tracked
                    wormArea2(i-start+1,:) =stats(id2).Area; %area of worm
                    %isolate the worm to be tracked from the rest
                    worm2 = false(size(bw2));
                    worm2(cc.PixelIdxList{id2}) = true;
                    while (findspline == 0)
    
                        bw3_2 = bwmorph(worm2, 'thin', inf);
                        figure(2); imshow(bw3_2); [t0_2,b0_2] = ginput(2); %manually define the head (1) and tail (2) in the first image by clicking on it.
                        % construct a question, questdlg, with three options
                        hold on; plot(t0_2(1),b0_2(1), 'r*'); plot(t0_2(2),b0_2(2), 'y*'); %plot head and tail points
                        choice = questdlg('Are the spline settings good?','settings','yes','no','yes');
                        % handle response
                        switch choice
                            case 'yes'
                                findspline = 1;
                            case 'no'
                                findspline = 0;
                        end
                    end 
                end
                % k=i-Rstart+1;
                % eval(['worm_diff_' num2str(k) '= bw2-worm;']) %this is the figure without the worm
                %figure(3); imshow(bw2);
                % figure(4); imshow(worm);
                % figure(5); imshow(worm_diff_0);
                
            elseif cc.NumObjects <=1
                worm=bw2;
                com(i-start+1,:)    = stats.Centroid;
                wormArea(i-start+1,:) =stats.Area; %area of worm
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Switch to manual mode when worms are crossing in or touching,
            % since one needs to then isolate the worm first
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if i-start==0
                if wormArea(i-start+1)>= 1.1*A0worm
                    figure; Qim=roipoly(bw2); hold on
                    worm = false(size(bw2));
                    worm(Qim) = true;
                    Nstats   = regionprops(worm, 'centroid', 'area'); %finds centroid and area of all worms
                    com(i-start+1,:)= Nstats.Centroid; %redefine the center of mass of the worm to be tracked
                    wormArea(i-start+1,:) =Nstats.Area; %area of worm
                end
            elseif i-start>=1
                if wormArea(i-start+1)>= 1.1*wormArea(i-start)
                    
                    figure; Qim=roipoly(bw2); hold on
                    worm = false(size(bw2));
                    worm(Qim) = true;
                    Nstats   = regionprops(worm, 'centroid', 'area'); %finds centroid and area of all worms
                    com(i-start+1,:)= Nstats.Centroid; %redefine the center of mass of the worm to be tracked
                    wormArea(i-start+1,:) =Nstats.Area; %area of worm
                    
                    
                end
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Now that the worm was identified, go ahead and create the spline and continue with all further
            % analysis
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            bw3 = bwmorph(worm, 'thin', inf);
            [rows,cols] = find(bw3>0);
            bw4 = bwmorph(bw3, 'endpoints');
            [b,t] = find(bw4>0); %b,t give the coordinates of the endpoints of the skeletonized worm
            %------------------------------------------------------------------
            %-- careful! which end is head vs tail in image 1 is determined by
            %worm's start position - the user defines it by clicking on it in
            %image 1; then we do a nearest neigbor analysis for all the other
            %images to determine head and tail in those
            %--------------------------------------------------------------
            b0=round(b0);t0=round(t0); %unordered head and tail coordinates in the first image
            
            if (find_tail==1)
                bw3_2 = bwmorph(worm2, 'thin', inf);
                [rows2,cols2] = find(bw3_2>0);
                bw4_2 = bwmorph(bw3_2, 'endpoints');
                [b2,t2] = find(bw4_2>0); %b,t give the coordinates of the endpoints of the skeletonized worm
                b0_2=round(b0_2);t0_2=round(t0_2);
            end
            
            %The algorithm below makes sure that the head stays the head and
            %the tail stays the tail point by doing a nearest neighbor
            %comparison between the images and the first image (the assumption
            %is that the head and tail don't cross or come to close
            %------------------------------------------------------------------
            if i-start==0
                db1=sqrt((b0(1)-b(1)).^2+(t0(1)-t(1)).^2); %the head's coordinates in image 1 are [t0(1),b0(1)]
                db2=sqrt((b0(1)-b(2)).^2+(t0(1)-t(2)).^2); %the tail is [t0(2),b0(2)];
                if db1>db2
                    nb(i-start+1,1)=b(1); nt(i-start+1,1)=t(1);
                    nb(i-start+1,2)=b(2); nt(i-start+1,2)=t(2);
                else
                    nb(i-start+1,1)=b(2);nt(i-start+1,1)=t(2);
                    nb(i-start+1,2)=b(1);nt(i-start+1,2)=t(1);
                end
            elseif i-start >=1
                % b0=nb(i-Rstart+1); t0=nt(i-Rstart+1);
                db1=sqrt((nb(i-start+1,1)-b(1)).^2+(nb(i-start+1,2)-t(1)).^2); %the head's coordinates in image 1 are [t0(1),b0(1)]
                db2=sqrt((nt(i-start+1,1)-b(2)).^2+(nt(i-start+1,2)-t(2)).^2); %the tail is [t0(2),b0(2)];
                if db1<db2
                    nb(i-start+1,1)=b(1); nt(i-start+1,1)=t(1);
                    nb(i-start+1,2)=b(2); nt(i-start+1,2)=t(2);
                else
                    nb(i-start+1,1)=b(2);nt(i-start+1,1)=t(2);
                    nb(i-start+1,2)=b(1);nt(i-start+1,2)=t(1); %save in new vectors nb and nt in the right order
                end
            end
            % nb=nb';nt=nt';
            head(i-start+1,:)=nb(i-start+1,:); tail(i-start+1,:)=nt(i-start+1,:); %save endpoints in vectors b and t
            eval(['row_' num2str(i-start+1) '=rows;']) %save row and col coordinates for each single image
            eval(['col_' num2str(i-start+1) '=cols;'])
            
            if (find_tail==1)
                    nb2=zeros(finish+1-brk,2);
                    nt2=zeros(finish+1-brk,2);
                    hy2=zeros(finish+1-brk,1);
                    ty2=zeros(finish+1-brk,1);
                    hx2=zeros(finish+1-brk,1);
                    tx2=zeros(finish+1-brk,1);
            if i-brk==0
                db1_2=sqrt((b0_2(1)-b2(1)).^2+(t0_2(1)-t2(1)).^2); %the head's coordinates in image 1 are [t0(1),b0(1)]
                db2_2=sqrt((b0_2(1)-b2(2)).^2+(t0_2(1)-t2(2)).^2); %the tail is [t0(2),b0(2)];
                if db1_2>db2_2
                    nb2(i-brk+1,1)=b2(1); nt2(i-brk+1,1)=t2(1);
                    nb2(i-brk+1,2)=b2(2); nt2(i-brk+1,2)=t2(2);
                else
                    nb2(i-brk+1,1)=b2(2);nt2(i-brk+1,1)=t2(2);
                    nb2(i-brk+1,2)=b2(1);nt2(i-brk+1,2)=t2(1);
                end
            elseif i-start >=1
                % b0=nb(i-Rstart+1); t0=nt(i-Rstart+1);
                db1_2=sqrt((nb2(i-brk+1,1)-b2(1)).^2+(nb2(i-brk+1,2)-t2(1)).^2); %the head's coordinates in image 1 are [t0(1),b0(1)]
                db2_2=sqrt((nt2(i-brk+1,1)-b2(2)).^2+(nt2(i-brk+1,2)-t2(2)).^2); %the tail is [t0(2),b0(2)];
                if db1_2<=db2_2
                    nb2(i-brk+1,1)=b2(1); nt2(i-brk+1,1)=t2(1);
                    nb2(i-brk+1,2)=b2(2); nt2(i-brk+1,2)=t2(2);
                else
                    nb2(i-brk+1,1)=b2(2);nt2(i-brk+1,1)=t2(2);
                    nb2(i-brk+1,2)=b2(1);nt2(i-brk+1,2)=t2(1); %save in new vectors nb and nt in the right order
                end
            end
            % nb=nb';nt=nt';
            head2(i-brk+1,:)=nb2(i-brk+1,:); tail2(i-brk+1,:)=nt2(i-brk+1,:); %save endpoints in vectors b and t
            eval(['row2_' num2str(i-brk+1) '=rows2;']) %save row and col coordinates for each single image
            eval(['col2_' num2str(i-brk+1) '=cols2;'])
            end
            %--------------------------------------------------------------
            
            clear im im_crop imc
            
            % --- coordinates; use function regionprops for tracking ---
            
            
            %----------------------------------------------------------------------
            
            %stats   = regionprops(worm, 'Centroid', 'Area');
            %com(i-start+1,:)   = stats.Centroid; %center of mass of worm
            %wormArea(i-Rstart+1,:) =stats.Area; %area of worm
            cc_cm = bwconncomp(bw2); %find connected components in image to identify worm
            L_cm = labelmatrix(cc_cm); %create label matrix
            
            stats_cm   = regionprops(L_cm, 'centroid', 'area'); %finds centroid and area of all worms
            
             if (cc_cm.NumObjects == 2) && (find_tail==1)
                 com1_cm = stats_cm(1).Centroid; com1x_cm = com1_cm(1,1); com1y_cm = com1_cm(1,2); area1_cm = stats_cm(1).Area;
                 com2_cm = stats_cm(2).Centroid; com2x_cm = com2_cm(1,1); com2y_cm = com2_cm(1,2); area2_cm = stats_cm(2).Area;
                 xcrop = (com1x_cm*area1_cm + com2x_cm*area2_cm)/(area1_cm + area2_cm);
                 ycrop = (com1y_cm*area1_cm + com2y_cm*area2_cm)/(area1_cm + area2_cm);
             elseif (cc_cm.NumObjects == 1)
                 cm = stats_cm(1).Centroid;
                 xcrop = cm(1,1);
                 ycrop = cm(1,2);
             else
                 xcrop = com(i-start+1,1);
                 ycrop = com(i-start+1,2);
             end
             x(i-start+1)    = c - w - 1 + xcrop; % position in present original image
             y(i-start+1)    = r - w - 1 + ycrop; % position in present original image
             r0       = round(y(i-start+1)); % row, for positioning the next cropping window
             c0       = round(x(i-start+1)); % column
            
            %----------------------------------------------------------------
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        output = 1;
            if output==1
            tx1(i-start+1) = tail(i-start+1,1); ty1(i-start+1) = head(i-start+1,1);
            hx1(i-start+1) = tail(i-start+1,2); hy1(i-start+1) = head(i-start+1,2);
            figure(5); imshow(worm); hold on; 
            plot(tx1(i-start+1),ty1(i-start+1),'b*');plot(hx1(i-start+1),hy1(i-start+1),'y*');
        out=1;
            if out==0
                figure(4), imshow(worm); hold on;
                plot(tx1(i-start+1),ty1(i-start+1),'b*');plot(hx1(i-start+1),hy1(i-start+1),'y*');
                hold off; %1 is head and 2 is tail
                % legend('worm', 'skeletonized',2)
                if output==1
                    % activate the printing feature if you want to save the image sequence for
                    % a movie
                    
                    cd(savepath);
                    printname =  ['shape1_' file]; % used when creating pdf
                    eval(['print -djpeg ' ,printname '.jpg']) %print figure as jpg.
                end
                cd(imdir);
            end
            if (find_tail==1)
                tx2(i+1-brk) = tail2(i-brk+1,1); ty2(i-brk+1) = head2(i-brk+1,1);
                hx2(i+1-brk) = tail2(i-brk+1,2); hy2(i-brk+1) = head2(i-brk+1,2);
                figure(6); imshow(worm2); hold on;
                plot(tx2(i-brk+1),ty2(i-brk+1),'b*');plot(hx2(i-brk+1),hy2(i-brk+1),'y*');
                if out==0
                figure(4), imshow(worm2); hold on;
                plot(tx2(i-brk+1),ty2(i-brk+1),'b*');plot(hx2(i-brk+1),hy2(i-brk+1),'y*');
                hold off; %1 is head and 2 is tail
                % legend('worm', 'skeletonized',2)
                if output==1
                    % activate the printing feature if you want to save the image sequence for
                    % a movie
                    
                    cd(savepath);
                    printname =  ['shape2_' file]; % used when creating pdf
                    eval(['print -djpeg ' ,printname '.jpg']) %print figure as jpg.
                end
                cd(imdir);
                end
            end
            hold off
            end
            
            % once the head is well defined, one can proceed with reorganizing the
            % spline
            
            %   cd(savepath);
            % seq_file = ['cropped_' seq_name front num2str(i) '.' file_type];
            % imwrite(im_crop, seq_file,file_type);
            
        end
        A0worm = Aiworm;
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%----save workspace --------------
cd(savepath)
save(eval(['savename'])) %saves the current workspace with its name
%--------------------------------------------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%-----------END--------------------END-----------------END-----------------

% this is the end of the tracking routine

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%----- here begins the actual sorting of the spline ----------------


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%--------------------------------------------------------------------------

analysis =1; %activate if you want to run the analysis part and get the spline

if analysis ==1
    
    %--------------------------------------------------------------------------
    %now the problem with these indices returned by 'find' is that they are in a
    %funny order. 'find' basically scans throught the matrix on a row by row
    %basis and then returns the values that are =1; the cols come automatically
    %with the rows. in order to be able to use those coordinates, they need to
    %be reordered properly. for this, we will start out with one of the
    %endpoints, let's say the 'head', and then via a shortest distance
    %algorithm find the next pixel, etc. we will then write all of this to a
    %new matrix "worm".
    %--------------------------------------------------------------------------
    
    q=1; %q is the running variable that indicates the images number
    while q<=finish-start+1;
%    while q==1;  
        h=[hx1(q),hy1(q)]; %this is the head of the worm
        %row=row_1;col=col_1;
        eval(['row = row_' num2str(q) ';'])
        eval(['col = col_' num2str(q) ';'])
        Sworm = [col,row]; %combine the rows and column vectors into a single matrix
        %start with the 'head'
        x0_1=h(1); 
        y0_1=h(2);
        eval(['mx_' num2str(q) '=zeros(length(row),1);'])
        eval(['my_' num2str(q) '=zeros(length(row),1);'])
        eval(['mx_' num2str(q) '(1)=x0_1;'])
        eval(['my_' num2str(q) '(1)=y0_1;'])
        k=2;
        d=zeros(length(row),1);
        while k<=length(row);
            for i_s=1:length(row);
                if d(i_s)~=inf
                    d(i_s)=sqrt((x0_1-Sworm(i_s,1)).^2+(y0_1-Sworm(i_s,2)).^2);
                end
                if d(i_s)==0
                    d(i_s)=inf;
                elseif d(i_s)==inf
                    d(i_s)=inf;
                else
                    d(i_s)=d(i_s);
                end
            end
            dmin=min(d);
            index=find(d==dmin);
            new_x0=Sworm(index,1);new_y0=Sworm(index,2);
            eval(['mx_' num2str(q) '(k)=new_x0;']) %save values in new matrices mx and my in the right order
            eval(['my_' num2str(q) '(k)=new_y0;'])
            x0_1=new_x0;
            y0_1=new_y0;
            k=k+1;
        end
        q=q+1;
    end
    
    
if (find_tail==1)
    qq=1;
    while qq<=finish-brk+1;
        h2=[hx2(qq),hy2(qq)]; %this is the head of the worm
        %row=row_1;col=col_1;
        eval(['row2 = row2_' num2str(qq) ';'])
        eval(['col2 = col2_' num2str(qq) ';'])
        Sworm2 = [col2,row2]; %combine the rows and column vectors into a single matrix
        %start with the 'head'
        x0_2=h2(1); 
        y0_2=h2(2);
        eval(['mx2_' num2str(qq) '=zeros(length(row2),1);'])
        eval(['my2_' num2str(qq) '=zeros(length(row2),1);'])
        eval(['mx2_' num2str(qq) '(1)=x0_2;'])
        eval(['my2_' num2str(qq) '(1)=y0_2;'])
        kk=2;
        dd=zeros(length(row2),1);
        while kk<=length(row2);
            for i_s2=1:length(row2);
                if dd(i_s2)~=inf
                    dd(i_s2)=sqrt((x0_2-Sworm2(i_s2,1)).^2+(y0_2-Sworm2(i_s2,2)).^2);
                end
                if dd(i_s2)==0
                    dd(i_s2)=inf;
                elseif dd(i_s2)==inf
                    dd(i_s2)=inf;
                else
                    dd(i_s2)=dd(i_s2);
                end
            end
            dmin2=min(dd);
            index2=find(dd==dmin2);
            new_x02=Sworm2(index2,1);new_y02=Sworm2(index2,2);
            eval(['mx2_' num2str(qq) '(kk)=new_x02;']) %save values in new matrices mx and my in the right order
            eval(['my2_' num2str(qq) '(kk)=new_y02;'])
            
            x0_2=new_x02;
            y0_2=new_y02;
            kk=kk+1;
        end
        qq=qq+1;
    end
end
end
%--------------------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%---------------------- Quantification of Splines -------------------------
% Here we extract the modes of fission from the spline length pre-fission,
% the movement of the head pre-fission by tracking the head endpoint of the
% spline, and the recoil of the head and tail pieces post-fission by 
% tracking the length of each.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



dt = 1;

if (find_tail==0)
    stop = finish;
elseif (find_tail==1)
    stop = brk;
end

Lspline = zeros((stop-start),1);
Kspline = zeros((stop-start),1);
MSDhead = zeros((stop-start-1),1);

for jj=1:(stop-start)
    eval(['xx = mx_' num2str(jj) ';'])
    eval(['yy = my_' num2str(jj) ';'])
    
    N = 3;                 % Order of polynomial fit
    F = 9;                % Window length
    [b,g] = sgolay(N,F);   % Calculate S-G coefficients

    HalfWin  = ((F+1)/2) -1;
    
    x = smooth(xx);
    y = smooth(yy);
    
    for n = (F+1)/2:1:length(x)-(F+1)/2,
        % Zero-th derivative (smoothing only)
        SG0_y(n-(((F+1)/2) -1)) =   dot(g(:,1), y(n - HalfWin: n + HalfWin));
        SG0_x(n-(((F+1)/2) -1)) =   dot(g(:,1), x(n - HalfWin: n + HalfWin));
  
        % 1st differential
        SG1_y(n-(((F+1)/2) -1)) =   dot(g(:,2), y(n - HalfWin: n + HalfWin));
        SG1_x(n-(((F+1)/2) -1)) =   dot(g(:,2), x(n - HalfWin: n + HalfWin));
  
        % 2nd differential
        SG2_y(n-(((F+1)/2) -1)) = 2*dot(g(:,3)', y(n - HalfWin: n + HalfWin))';
        SG2_x(n-(((F+1)/2) -1)) = 2*dot(g(:,3)', x(n - HalfWin: n + HalfWin))';
    end
    
    dist_1 = zeros(length(SG0_x)-1,1);
    for nn = 1:length(SG0_x)-1
        dist_1(nn) = sqrt((SG0_x(1,nn)-SG0_x(1,nn+1))^2 + (SG0_y(1,nn)-SG0_y(1,nn+1))^2);
    end
    Lspline(jj) = sum(dist_1);
    
    K = zeros(length(SG2_x),1);
    for nnn=1:length(SG2_x)
        K(nnn) = abs(SG1_x(1,nnn)*SG2_y(1,nnn) - SG2_x(1,nnn)*SG1_y(1,nnn))/((SG1_x(1,nnn))^2 + (SG1_y(1,nnn))^2)^(3/2);
    end
    Kspline(jj) = mean(K);
    
    if jj<(brk-start)
        MSDhead(jj) = (sqrt((hx1(1)-hx1(jj+1))^2 + (hy1(1)-hy1(jj+1))^2))^2;
    end
end

Lspline_max = Lspline/max(Lspline);
Lspline_min = Lspline/min(Lspline);
Kspline = Kspline/max(Kspline);

msdt = 1:length(MSDhead);
klt = 1:length(Kspline);

figure(7); hold on;
plot(klt,Lspline_max,'b');
plot(klt,Lspline_min,'c');
plot(klt,Kspline,'r');
hold off

figure(8); hold on
plot(msdt,MSDhead,'r');
hold off

if (find_tail==1)
    
Lspline_h = zeros((finish-brk),1);
Lspline_t = zeros((finish-brk),1);

for z=(brk-start+1):(finish-start)
    eval(['xxh = mx_' num2str(z) ';'])
    eval(['yyh = my_' num2str(z) ';'])
    eval(['xxt = mx2_' num2str(z-(brk-start)) ';'])
    eval(['yyt = my2_' num2str(z-(brk-start)) ';'])
    
    N = 3;                 % Order of polynomial fit
    F = 9;                % Window length
    [b,g] = sgolay(N,F);   % Calculate S-G coefficients

    HalfWin  = ((F+1)/2) -1;
    
    xh = smooth(xxh);
    yh = smooth(yyh);
    xt = smooth(xxt);
    yt = smooth(yyt);
    
    for n = (F+1)/2:1:length(xh)-(F+1)/2,
        % Zero-th derivative (smoothing only)
        SG0_yh(n-(((F+1)/2) -1)) =   dot(g(:,1), yh(n - HalfWin: n + HalfWin));
        SG0_xh(n-(((F+1)/2) -1)) =   dot(g(:,1), xh(n - HalfWin: n + HalfWin));
  
        % 1st differential
        SG1_yh(n-(((F+1)/2) -1)) =   dot(g(:,2), yh(n - HalfWin: n + HalfWin));
        SG1_xh(n-(((F+1)/2) -1)) =   dot(g(:,2), xh(n - HalfWin: n + HalfWin));
  
        % 2nd differential
        SG2_yh(n-(((F+1)/2) -1)) = 2*dot(g(:,3)', yh(n - HalfWin: n + HalfWin))';
        SG2_xh(n-(((F+1)/2) -1)) = 2*dot(g(:,3)', xh(n - HalfWin: n + HalfWin))';
    end
    
    for n = (F+1)/2:1:length(xt)-(F+1)/2,
        % Zero-th derivative (smoothing only)
        SG0_yt(n-(((F+1)/2) -1)) =   dot(g(:,1), yt(n - HalfWin: n + HalfWin));
        SG0_xt(n-(((F+1)/2) -1)) =   dot(g(:,1), xt(n - HalfWin: n + HalfWin));
        
        % 1st differential
        SG1_yt(n-(((F+1)/2) -1)) =   dot(g(:,2), yt(n - HalfWin: n + HalfWin));
        SG1_xt(n-(((F+1)/2) -1)) =   dot(g(:,2), xt(n - HalfWin: n + HalfWin));
        
        % 2nd differential
        SG2_yt(n-(((F+1)/2) -1)) = 2*dot(g(:,3)', yt(n - HalfWin: n + HalfWin))';
        SG2_xt(n-(((F+1)/2) -1)) = 2*dot(g(:,3)', xt(n - HalfWin: n + HalfWin))';
    end
    
    dist_1h = zeros(length(SG0_xh)-1,1);
    for nh = 1:length(SG0_xh)-1
        dist_1h(nh) = sqrt((SG0_xh(1,nh)-SG0_xh(1,nh+1))^2 + (SG0_yh(1,nh)-SG0_yh(1,nh+1))^2);
    end
    Lspline_h(z-(brk-start)) = sum(dist_1h);
    
    dist_1t = zeros(length(SG0_xt)-1,1);
    for nt = 1:length(SG0_xt)-1
        dist_1t(nt) = sqrt((SG0_xt(1,nt)-SG0_xt(1,nt+1))^2 + (SG0_yt(1,nt)-SG0_yt(1,nt+1))^2);
    end
    Lspline_t(z-(brk-start)) = sum(dist_1t);
end

Lspline_hmin = Lspline_h/min(Lspline_h);
Lspline_tmin = Lspline_t/min(Lspline_t);
recoil_t = 1:length(Lspline_h);

figure(9); hold on
plot(recoil_t,Lspline_hmin,'r');
plot(recoil_t,Lspline_tmin,'b');
hold off

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%----save entire workspace in directory specified at the beginning-----
cd(savepath)
save(eval(['savename'])) %saves the current workspace with its name
%--------------------------------------------------------------------------

%close all

