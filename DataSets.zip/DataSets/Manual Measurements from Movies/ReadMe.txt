This folder contains data that was extracted from video recordings of dividing planarians as described in Section 2.2 of the main manuscript.
The headers for each column describe the measurement. See Supplementary figure S3A for a visual representation of the measurements.

These data were used to generate the following figures:

1. Figure 3
2. Figure 4B
3. Rupture duration (section 3.4)
4. Figure 7C
5. Figure S7B
6. Figure S8A-C
7. Figure S10



Note: "NA" and blank cells in data denote measurements that were not available either because the raw images were too blurred or the orientation of the planarian did not allow measurement.
