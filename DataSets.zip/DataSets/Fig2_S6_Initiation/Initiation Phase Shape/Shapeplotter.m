%% This script reads the .mat files in the folder spit out by the Wormprocessor code.
%%The mat file contains the x,y coordinates of the spline (ordered head to tail)
%%and corresponding distances to the boundary. These are stored in a 3
%%column matrix named 'spline_matrix'. All measurements are stored as
%%pixels.
%%The code maps the spline onto [0(head),1(tail)] and plots the edge
%%distance as a function of the normalized spline length.
%%The edge distance is normalized to worm rest length which is also a
%%user input.

%%Written: June 11th 2020, Tapan Goel
%%Modified: June 12th 2021, Tapan Goel

clear all; clc; clf; close all;

filename = input('Enter Mat File Name:','s') %Enter the name of the matfile with full path name.
load(filename,'spline_matrix');

x = spline_matrix(:,1);
y = spline_matrix(:,2);
z = spline_matrix(:,3);

dx = x(2:end)-x(1:end-1);
dy = y(2:end)-y(1:end-1);
ds = [0 sqrt(dx.*dx + dy.*dy)];
s = cumsum(ds)./sum(ds)  %% generates a coordinate along the length of the worm, so that head is designated 0 and tail is desingated 1.

plot(s,z);


